package com.example.tening_sene;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import android.view.View;
import android.content.Intent;

public class DetailActivity extends AppCompatActivity {
    private TextView titleTextView;
    private TextView contentTextView;
    private FloatingActionButton fabBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.detail);

        titleTextView = findViewById(R.id.titleTextView);
        contentTextView = findViewById(R.id.contentTextView);
        fabBack = findViewById(R.id.floatingActionButton);

        // Obtenir l'article sélectionné de l'intent
        Article article = (Article) getIntent().getSerializableExtra("article");

        // Afficher les détails de l'article
        if (article != null) {
            titleTextView.setText(article.getTitre());
            contentTextView.setText(article.getContenu());
        }

        // Ajouter un écouteur de clic sur le bouton "Retour"
        fabBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Revenir à la page pour lister les articles
                Intent intent = new Intent(DetailActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }
}
