package com.example.tening_sene;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.List;

public class MainActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private ArticleAdapter articleAdapter;
    private List<Article> articleList;
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerView);
        FloatingActionButton fabAddArticle = findViewById(R.id.fabAddArticle);

        databaseHelper = new DatabaseHelper(this);

        // Configurer l'adaptateur et le gestionnaire de disposition pour RecyclerView
        articleList = getArticles();
        articleAdapter = new ArticleAdapter(articleList);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(articleAdapter);

        // Ajouter un écouteur de clic sur le bouton "Ajouter un article"
        fabAddArticle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Passer à la page d'ajout d'article
                Intent intent = new Intent(MainActivity.this, AjouterActivity.class);
                startActivity(intent);
            }
        });

        // Ajouter un écouteur de clic sur les éléments de RecyclerView
        articleAdapter.setOnItemClickListener(new ArticleAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(int position) {
                Article article = articleList.get(position);
                Intent intent = new Intent(MainActivity.this, DetailActivity.class);
                intent.putExtra("article", article);
                startActivity(intent);
            }
        });

        // Ajouter un écouteur de suppression sur les éléments de RecyclerView
        articleAdapter.setOnDeleteClickListener(new ArticleAdapter.OnDeleteClickListener() {
            @Override
            public void onDeleteClick(int position) {
                Article article = articleList.get(position);
                deleteArticle(article);
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Mettre à jour la liste des articles lorsque l'activité reprend le premier plan
        articleList = getArticles();
        articleAdapter.setArticles(articleList);
    }

    private List<Article> getArticles() {
        return databaseHelper.getAllArticles();
    }

    private void deleteArticle(Article article) {
        databaseHelper.deleteArticle(article);
        articleList.remove(article);
        articleAdapter.setArticles(articleList);
    }
}
