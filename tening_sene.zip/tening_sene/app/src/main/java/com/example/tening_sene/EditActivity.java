package com.example.tening_sene;
import androidx.appcompat.app.AppCompatActivity;
import android.widget.Toast;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.util.Log;

import com.example.tening_sene.Article;
public class EditActivity extends AppCompatActivity {
    private EditText editTextTitre;
    private EditText editTextContenu;
    private Button buttonModifier;

    private Article article;
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.edit_activity);

        // Initialiser DatabaseHelper
        databaseHelper = new DatabaseHelper(this);

        editTextTitre = findViewById(R.id.editTextTitre);
        editTextContenu = findViewById(R.id.editTextContenu);
        buttonModifier = findViewById(R.id.buttonModifier);

        // Récupérer l'article transmis depuis MainActivity
        article = getIntent().getParcelableExtra("article");

        if (article != null) {
            // Définir l'ID de l'article
            article.setId(article.getId());

            // Remplir les champs avec les valeurs actuelles de l'article
            editTextTitre.setText(article.getTitre());
            editTextContenu.setText(article.getContenu());
        } else {
            // Afficher un message d'erreur si l'article n'est pas trouvé
            Toast.makeText(this, "Article introuvable", Toast.LENGTH_SHORT).show();
            finish(); // Fermer l'activité si l'article n'est pas trouvé
        }

        // Ajouter un écouteur de clic sur le bouton "Modifier"
        buttonModifier.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                modifierArticle();
            }
        });
    }
    private void modifierArticle() {
        Log.d("AVANT MISE À JOUR", "Titre: " + article.getTitre() + ", Contenu: " + article.getContenu());
        // Récupérer les nouvelles valeurs du titre et du contenu
        String nouveauTitre = editTextTitre.getText().toString().trim();
        String nouveauContenu = editTextContenu.getText().toString().trim();

        // Vérifier que les champs ne sont pas vides
        if (nouveauTitre.isEmpty() || nouveauContenu.isEmpty()) {
            // Afficher un message d'erreur si les champs sont vides
            Toast.makeText(this, "Veuillez remplir tous les champs", Toast.LENGTH_SHORT).show();
            return;
        }


        // Mettre à jour les valeurs de l'article
        article.setTitre(nouveauTitre);
        article.setContenu(nouveauContenu);

        // Mettre à jour l'article dans la base de données
        int rowsAffected = databaseHelper.updateArticle(article);

        if (rowsAffected > 0) {
            // Afficher un message de succès si des lignes ont été affectées
            Toast.makeText(this, "Article modifié avec succès", Toast.LENGTH_SHORT).show();
        } else {
            // Afficher un message d'erreur si aucune ligne n'a été affectée
            Toast.makeText(this, "Erreur lors de la modification de l'article", Toast.LENGTH_SHORT).show();
        }

        Log.d("APRÈS MISE À JOUR", "Titre: " + article.getTitre() + ", Contenu: " + article.getContenu());

        // Fermer l'activité et revenir à MainActivity
        finish();
    }

}
