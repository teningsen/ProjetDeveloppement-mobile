package com.example.tening_sene;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class AjouterActivity extends AppCompatActivity {

    private EditText editTitre;
    private EditText editContenu;
    private FloatingActionButton fabAjouter;
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.ajouter);

        editTitre = findViewById(R.id.editTextTitre);
        editContenu = findViewById(R.id.editTextContenu);
        fabAjouter = findViewById(R.id.floatingActionButton);

        databaseHelper = new DatabaseHelper(this);

        fabAjouter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                validerEtAjouterArticle();
            }
        });
    }

    private void validerEtAjouterArticle() {
        String titre = editTitre.getText().toString();
        String contenu = editContenu.getText().toString();

        if (isValidData(titre, contenu)) {
            ajouterArticle(titre, contenu);
            retournerALaListeDesArticles();
        } else {
            Toast.makeText(AjouterActivity.this, "Veuillez remplir tous les champs", Toast.LENGTH_SHORT).show();
        }
    }

    private boolean isValidData(String titre, String contenu) {
        return !TextUtils.isEmpty(titre) && !TextUtils.isEmpty(contenu);
    }

    private void ajouterArticle(String titre, String contenu) {
        Article nouvelArticle = new Article(titre, contenu);
        long id = databaseHelper.insertArticle(nouvelArticle);
        nouvelArticle.setId(id);
    }

    private void retournerALaListeDesArticles() {
        Intent intent = new Intent(AjouterActivity.this, MainActivity.class);
        startActivity(intent);
        finish(); // Fermer l'activité Ajouter une fois qu'on revient à la liste des articles
    }
}
