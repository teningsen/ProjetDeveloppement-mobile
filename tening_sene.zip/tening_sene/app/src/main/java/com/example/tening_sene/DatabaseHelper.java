package com.example.tening_sene;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "article_db";
    private static final int DATABASE_VERSION = 1;
    private static final String TABLE_NAME = "articles";
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_TITLE = "title";
    private static final String COLUMN_CONTENT = "content";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTableQuery = "CREATE TABLE " + TABLE_NAME + " (" +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_TITLE + " TEXT, " +
                COLUMN_CONTENT + " TEXT)";
        db.execSQL(createTableQuery);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        String dropTableQuery = "DROP TABLE IF EXISTS " + TABLE_NAME;
        db.execSQL(dropTableQuery);
        onCreate(db);
    }

    public long insertArticle(Article article) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_TITLE, article.getTitre());
        values.put(COLUMN_CONTENT, article.getContenu());
        long id = db.insert(TABLE_NAME, null, values);
        db.close();
        return id;
    }

    public Article getArticleById(long id) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_NAME, null, COLUMN_ID + "=?",
                new String[]{String.valueOf(id)}, null, null, null);

        Article article = null;
        if (cursor != null && cursor.moveToFirst()) {
            int titleIndex = cursor.getColumnIndex(COLUMN_TITLE);
            int contentIndex = cursor.getColumnIndex(COLUMN_CONTENT);

            if (titleIndex >= 0 && contentIndex >= 0) {
                String titre = cursor.getString(titleIndex);
                String contenu = cursor.getString(contentIndex);
                article = new Article(titre, contenu);
                article.setId(id); // Définir l'ID de l'article séparément
            }

            cursor.close();
        }
        db.close();
        return article;
    }






    public List<Article> getAllArticles() {
        List<Article> articles = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_NAME, null, null,
                null, null, null, null);

        if (cursor != null && cursor.moveToFirst()) {
            do {
                int idIndex = cursor.getColumnIndex(COLUMN_ID);
                int titleIndex = cursor.getColumnIndex(COLUMN_TITLE);
                int contentIndex = cursor.getColumnIndex(COLUMN_CONTENT);

                if (idIndex >= 0 && titleIndex >= 0 && contentIndex >= 0) {
                    long id = cursor.getLong(idIndex);
                    String titre = cursor.getString(titleIndex);
                    String contenu = cursor.getString(contentIndex);
                    Article article = new Article(id, titre, contenu);
                    articles.add(article);
                }
            } while (cursor.moveToNext());

            cursor.close();
        }
        db.close();
        return articles;
    }

    public int updateArticle(Article article) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_TITLE, article.getTitre());
        values.put(COLUMN_CONTENT, article.getContenu());
        int rowsAffected = db.update(TABLE_NAME, values, COLUMN_ID + "=?",
                new String[]{String.valueOf(article.getId())});
        db.close();
        return rowsAffected;
    }

    public void deleteArticle(Article article) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_NAME, COLUMN_ID + "=?",
                new String[]{String.valueOf(article.getId())});
        db.close();
    }
}
